import 'package:flutter/material.dart';

void main() => runApp(const SmartSathiApp());

class SmartSathiApp extends StatelessWidget {
  const SmartSathiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartSathi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF21652E)),
        scaffoldBackgroundColor: const Color(0xFFF3F7F1),
        fontFamily: 'Roboto',
      ),
      home: const SmartSathiHome(),
    );
  }
}

class AppModule {
  final String category;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color tint;
  const AppModule(this.category, this.title, this.subtitle, this.icon, this.tint);
}

const modules = <AppModule>[
  AppModule('Academics & Study Hub', 'Notes & PDF Storage', 'Save and access study notes, books and PDFs', Icons.picture_as_pdf, Color(0xFFE8EAF6)),
  AppModule('Academics & Study Hub', 'Subjects & Courses', 'Manage study courses and subjects', Icons.menu_book, Color(0xFFE8EAF6)),
  AppModule('Academics & Study Hub', 'Academic Profile & CGPA', 'Grades, SGPA and performance trends', Icons.bar_chart, Color(0xFFE8EAF6)),
  AppModule('Finance & Money Manager', 'Money Dashboard', 'Overview of finances and net worth', Icons.account_balance, Color(0xFFE4F0E6)),
  AppModule('Finance & Money Manager', 'Expenses Tracker', 'Track where your money goes', Icons.payments, Color(0xFFFCE7E7)),
  AppModule('Finance & Money Manager', 'Income Manager', 'Manage earnings, salary and cash flow', Icons.account_balance_wallet, Color(0xFFE4F0E6)),
  AppModule('Finance & Money Manager', 'Udhar (Lend/Borrow)', 'Manage personal debts and credits', Icons.handshake, Color(0xFFFFF1DD)),
  AppModule('Finance & Money Manager', 'Financial Analytics', 'View spending and income trends', Icons.query_stats, Color(0xFFE4F0E6)),
  AppModule('Health, Wellness & Daily Life', 'Medicine Tracker', 'Dose reminders and stock refills', Icons.medical_services, Color(0xFFFCE7E7)),
  AppModule('Health, Wellness & Daily Life', 'Water Hydration', 'Stay hydrated daily with logs', Icons.water_drop, Color(0xFFE0F2FA)),
  AppModule('Health, Wellness & Daily Life', 'Sleep Quality Logs', 'Track sleep duration and recovery', Icons.nightlight_round, Color(0xFFEDE7F6)),
  AppModule('Health, Wellness & Daily Life', 'Food & Meal Tracker', 'Log meals and nutrition', Icons.restaurant, Color(0xFFFCE8E2)),
  AppModule('Health, Wellness & Daily Life', 'Gratitude & Reflections', 'Journaling and positive reflections', Icons.volunteer_activism, Color(0xFFE4F0E6)),
  AppModule('Sadhana & Spiritual Discipline', 'Sadhana & Meditation', 'Chanting, meditation and yoga timers', Icons.self_improvement, Color(0xFFFFF5DC)),
  AppModule('Sadhana & Spiritual Discipline', 'Habits & Streaks', 'Build daily discipline and routines', Icons.auto_graph, Color(0xFFE4F0E6)),
  AppModule('Smart Planner & Productivity', 'Smart Daily Planner', '24-hour schedule, goals and routines', Icons.calendar_month, Color(0xFFE0F2F1)),
  AppModule('Smart Planner & Productivity', 'Personal Insights Engine', 'Study, productivity and wellness analytics', Icons.insights, Color(0xFFE8EAF6)),
  AppModule('Smart Planner & Productivity', 'Location & Route Tracker', 'Maps, trips and saved places', Icons.location_on, Color(0xFFE0F2F1)),
  AppModule('Smart Planner & Productivity', 'Notifications & Reminders', 'Central notification center and reminders', Icons.notifications_active, Color(0xFFFFF1DD)),
  AppModule('Vault & Security', 'Personal Document Vault', 'Organize important personal documents', Icons.folder_shared, Color(0xFFF3E5F5)),
  AppModule('Vault & Security', 'Disaster Recovery & Vault', 'Backup and export your app data', Icons.shield, Color(0xFFE8EAF6)),
];

const categoryIcons = <String, IconData>{
  'Academics & Study Hub': Icons.school,
  'Finance & Money Manager': Icons.savings,
  'Health, Wellness & Daily Life': Icons.spa,
  'Sadhana & Spiritual Discipline': Icons.self_improvement,
  'Smart Planner & Productivity': Icons.event_note,
  'Vault & Security': Icons.lock,
};

class SmartSathiHome extends StatefulWidget {
  const SmartSathiHome({super.key});
  @override
  State<SmartSathiHome> createState() => _SmartSathiHomeState();
}

class _SmartSathiHomeState extends State<SmartSathiHome> {
  int selectedTab = 5;
  String selectedFilter = 'All';
  String query = '';

  List<AppModule> get visibleModules {
    return modules.where((m) {
      final q = query.trim().toLowerCase();
      final matchesQuery = q.isEmpty ||
          m.title.toLowerCase().contains(q) ||
          m.subtitle.toLowerCase().contains(q) ||
          m.category.toLowerCase().contains(q);
      final matchesFilter = selectedFilter == 'All' ||
          (selectedFilter == 'Academics' && m.category == 'Academics & Study Hub') ||
          (selectedFilter == 'Finance' && m.category == 'Finance & Money Manager') ||
          (selectedFilter == 'Wellness' &&
              (m.category == 'Health, Wellness & Daily Life' ||
               m.category == 'Sadhana & Spiritual Discipline'));
      return matchesQuery && matchesFilter;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<AppModule>>{};
    for (final m in visibleModules) {
      grouped.putIfAbsent(m.category, () => []).add(m);
    }
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF185A28), Color(0xFF2E7D32)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(4)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Container(
                      width: 58, height: 58,
                      decoration: BoxDecoration(
                        color: Colors.white, shape: BoxShape.circle,
                        border: Border.all(color: Colors.white70, width: 3),
                      ),
                      child: const Icon(Icons.hub, color: Color(0xFF21652E), size: 32),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('SmartSathi', style: TextStyle(color: Colors.white70, fontSize: 18)),
                        Text('All System Modules', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
                        Text('Built by Sanu Kumar', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    )),
                  ]),
                  const SizedBox(height: 22),
                  TextField(
                    onChanged: (v) => setState(() => query = v),
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Search any feature or tool...',
                      hintStyle: const TextStyle(color: Colors.white70),
                      prefixIcon: const Icon(Icons.search, color: Colors.white),
                      filled: true, fillColor: Colors.white.withOpacity(.13),
                      contentPadding: const EdgeInsets.symmetric(vertical: 18),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: const BorderSide(color: Colors.white54, width: 1.5),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: const BorderSide(color: Colors.white, width: 1.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: ['All', 'Academics', 'Finance', 'Wellness'].map((f) {
                      final active = selectedFilter == f;
                      return Padding(
                        padding: const EdgeInsets.only(right: 9),
                        child: ChoiceChip(
                          label: Text(f, style: TextStyle(
                            color: active ? const Color(0xFF205D2B) : Colors.white,
                            fontWeight: FontWeight.w700,
                          )),
                          selected: active,
                          showCheckmark: false,
                          backgroundColor: Colors.white.withOpacity(.18),
                          selectedColor: Colors.white,
                          onSelected: (_) => setState(() => selectedFilter = f),
                          side: BorderSide.none,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        ),
                      );
                    }).toList()),
                  ),
                ],
              ),
            ),
            Expanded(
              child: selectedTab == 4
                  ? const ProfilePanel()
                  : selectedTab != 5
                    ? SimplePanel(title: const ['Home', 'Goals', 'Timer', 'Analytics'][selectedTab], icon: [Icons.home, Icons.checklist, Icons.timer, Icons.bar_chart][selectedTab])
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
                        children: grouped.entries.map((entry) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(0, 8, 0, 14),
                                child: Row(children: [
                                  Icon(categoryIcons[entry.key] ?? Icons.widgets, color: const Color(0xFF21652E), size: 27),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(entry.key, style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF245F2D),
                                  ))),
                                  CircleAvatar(
                                    radius: 15, backgroundColor: const Color(0xFFDDE9DD),
                                    child: Text('${entry.value.length}', style: const TextStyle(color: Color(0xFF245F2D), fontWeight: FontWeight.bold)),
                                  ),
                                ]),
                              ),
                              ...entry.value.map((m) => ModuleCard(module: m)),
                              const SizedBox(height: 14),
                            ],
                          );
                        }).toList(),
                      ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 9, 16, 8),
              color: const Color(0xFFE7F0E5),
              child: const Row(children: [
                Icon(Icons.cloud_done_outlined, color: Color(0xFF426B48), size: 19),
                SizedBox(width: 7),
                Text('Cloud Sync ready to configure', style: TextStyle(color: Color(0xFF245F2D), fontWeight: FontWeight.w600)),
                Spacer(),
                Text('Sanu Kumar', style: TextStyle(color: Color(0xFF245F2D), fontWeight: FontWeight.bold)),
              ]),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: (i) => setState(() => selectedTab = i),
        backgroundColor: const Color(0xFFF7FAF6),
        indicatorColor: const Color(0xFFE2F1E3),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.checklist), label: 'Goals'),
          NavigationDestination(icon: Icon(Icons.timer_outlined), label: 'Timer'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Analytics'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class ModuleCard extends StatelessWidget {
  final AppModule module;
  const ModuleCard({super.key, required this.module});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1.5,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25), side: const BorderSide(color: Color(0xFFE8EDE7))),
      child: InkWell(
        borderRadius: BorderRadius.circular(25),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ModuleDetail(module: module))),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(children: [
            Container(
              width: 68, height: 68,
              decoration: BoxDecoration(color: module.tint, borderRadius: BorderRadius.circular(22)),
              child: Icon(module.icon, color: iconColor(module.tint), size: 32),
            ),
            const SizedBox(width: 15),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(module.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF252A25))),
                const SizedBox(height: 4),
                Text(module.subtitle, style: const TextStyle(fontSize: 14, color: Color(0xFF737A73), height: 1.35)),
              ],
            )),
            const Icon(Icons.chevron_right, color: Color(0xFF777F78), size: 28),
          ]),
        ),
      ),
    );
  }

  Color iconColor(Color tint) {
    if (tint == const Color(0xFFFCE7E7) || tint == const Color(0xFFFCE8E2)) return const Color(0xFFD83D45);
    if (tint == const Color(0xFFFFF1DD) || tint == const Color(0xFFFFF5DC)) return const Color(0xFFE39A15);
    if (tint == const Color(0xFFE0F2FA)) return const Color(0xFF1687B9);
    if (tint == const Color(0xFFE0F2F1)) return const Color(0xFF16877F);
    if (tint == const Color(0xFFEDE7F6) || tint == const Color(0xFFF3E5F5)) return const Color(0xFF6A3DA5);
    if (tint == const Color(0xFFE8EAF6)) return const Color(0xFF3949AB);
    return const Color(0xFF31763C);
  }
}

class ModuleDetail extends StatelessWidget {
  final AppModule module;
  const ModuleDetail({super.key, required this.module});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(module.title), backgroundColor: const Color(0xFFE7F0E5)),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(
            width: 100, height: 100,
            decoration: BoxDecoration(color: module.tint, borderRadius: BorderRadius.circular(28)),
            child: Icon(module.icon, size: 52, color: const Color(0xFF21652E)),
          )),
          const SizedBox(height: 24),
          Text(module.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(module.subtitle, style: const TextStyle(fontSize: 16, color: Colors.black54)),
          const SizedBox(height: 22),
          const Text('SmartSathi module', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('यह स्क्रीन शुरुआती प्रोजेक्ट का हिस्सा है। इस मॉड्यूल में डेटा सेव करने, रिमाइंडर या रिपोर्ट जैसी वास्तविक सुविधाएँ जोड़ने के लिए अगला चरण आवश्यक होगा।'),
          const Spacer(),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('इस सुविधा को अगले चरण में सक्रिय किया जाएगा।')),
            ),
            icon: const Icon(Icons.add),
            label: const Text('Add / Manage'),
          )),
        ]),
      ),
    );
  }
}

class SimplePanel extends StatelessWidget {
  final String title;
  final IconData icon;
  const SimplePanel({super.key, required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 70, color: const Color(0xFF21652E)),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('यह शुरुआती स्क्रीन है। इस सेक्शन में आगे काम करने वाली सुविधाएँ जोड़ी जा सकती हैं।', textAlign: TextAlign.center),
      ]),
    ),
  );
}

class ProfilePanel extends StatelessWidget {
  const ProfilePanel({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(radius: 45, backgroundColor: Color(0xFFDDE9DD), child: Icon(Icons.person, size: 48, color: Color(0xFF21652E))),
        SizedBox(height: 14),
        Text('Sanu Kumar', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        Text('SmartSathi App Builder', style: TextStyle(color: Colors.black54)),
        SizedBox(height: 18),
        Text('प्रोफाइल और अकाउंट सेटिंग्स को आगे जोड़ सकते हैं।', textAlign: TextAlign.center),
      ]),
    ),
  );
}
