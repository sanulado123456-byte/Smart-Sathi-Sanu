# SmartSathi — Flutter starter project

Built by: Sanu Kumar

## Included
- Screenshot-inspired green header, search field, category filters and bottom navigation
- All module cards listed in the supplied screenshots
- Module detail pages and starter Home / Goals / Timer / Analytics / Profile / More navigation
- App title and builder credit: SmartSathi / Sanu Kumar

## Important
This is a UI starter project, not a complete production app yet. Cloud sync, authentication, actual document storage, medicine notifications, financial records, maps and backups need real implementations and secure backend configuration. Avoid storing Aadhaar/PAN or other sensitive documents until secure storage and authentication are added.

## Build
1. Install Flutter SDK and Android Studio.
2. Extract this folder.
3. In a terminal inside this folder run:
   flutter pub get
   flutter run
4. To create an Android APK:
   flutter build apk --release

The APK is usually created at:
build/app/outputs/flutter-apk/app-release.apk

## Build APK using GitHub from a phone
This project includes `.github/workflows/build-apk.yml`. After uploading the extracted project files to a GitHub repository on the `main` branch:
1. Open the repository's **Actions** tab.
2. Select **Build SmartSathi APK**.
3. Tap **Run workflow** if shown, then open the completed run.
4. Under **Artifacts**, download `SmartSathi-APK`. It contains the APK.
GitHub login and internet access are required. The APK build is not performed until the workflow is run.
